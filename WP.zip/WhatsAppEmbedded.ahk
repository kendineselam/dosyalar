; ============================================================
;  WhatsApp (Gömülü Tarayıcı) - AHK v2 + WebView2
; ============================================================
;  Bu script WhatsApp Web'i AYRI bir Chrome/Edge programı açmak
;  yerine, DOĞRUDAN bu AHK scriptinin kendi penceresinin İÇİNE
;  gömer (Microsoft Edge WebView2 motoruyla). Yani ortaya kendi
;  başına bir "WhatsApp" uygulaması çıkıyor.
;
;  ÖZELLİKLER:
;   - Oturum kalıcı: QR'ı bir kez okutursun, bir daha istemez
;   - Mesaj + arama bildirimleri (izinler otomatik onaylanıyor)
;   - Dosya sürükle-bırak (PDF/Word/resim) WhatsApp Web'in kendi
;     özelliği, ekstra kod gerekmiyor
;   - Pencereyi kapatınca program kapanmaz, tepsiye küçülür,
;     bildirimler arka planda gelmeye devam eder
;
;  ------------------------------------------------------------
;  KURULUM (BİR KEZ YAPILACAK):
;  1) https://github.com/thqby/ahk2_lib adresine git
;  2) "WebView2" klasörünü indir (Code > Download ZIP, sonra
;     içinden sadece WebView2 klasörünü çıkar)
;  3) Bu .ahk dosyasıyla AYNI klasöre "Lib" adında bir klasör aç
;     ve WebView2 klasörünü içine koy. Sonuçta şöyle olmalı:
;         SeninKlasörün\WhatsAppEmbedded.ahk
;         SeninKlasörün\Lib\WebView2\WebView2.ahk
;         SeninKlasörün\Lib\WebView2\64bit\WebView2Loader.dll
;  4) Bilgisayarında Microsoft Edge WebView2 Runtime kurulu
;     olmalı (Windows 10/11'de zaten fabrika kurulu gelir,
;     yoksa Microsoft'un sitesinden indirilir).
; ============================================================

#Requires AutoHotkey v2.0
#SingleInstance Force
Persistent
; NOT: WebView2.ahk ve WebView2Loader.dll bu .ahk dosyasıyla
; AYNI klasörde, düz (alt klasörsüz) durmalı:
;   ...\WhatsAppEmbedded.ahk
;   ...\WebView2.ahk
;   ...\WebView2Loader.dll
#Include %A_ScriptDir%\WebView2.ahk

; Oturumun kalıcı olarak saklanacağı klasör (silmediğin sürece
; giriş bilgin burada kalır, tekrar QR okutmazsın)
UserDataFolder := A_AppData "\WhatsAppEmbeddedProfile"

global wvc := 0, wv := 0, main

; Windows'a bu programın "AutoHotkey" değil kendi kimliğiyle bilinen
; bir uygulama olduğunu bildir. Bu sayede bildirimlerde (Eylem
; Merkezi'nde) altta/üstte çıkan küçük gri kaynak yazısı artık
; "AutoHotkey" değil, burada verdiğimiz isim olur.
DllCall("shell32\SetCurrentProcessExplicitAppUserModelID", "wstr", "WhatsAppEmbedded.Masaustu.WhatsApp")

; Process önceliğini biraz yükselt: arka plandaki diğer programlar
; WhatsApp'ın render/tepki hızını çalmasın (agresif değil, güvenli seviye)
ProcessSetPriority("AboveNormal")

; Yüksek DPI ekranlarda bulanıklığı ve gereksiz yeniden ölçeklemeyi
; önlemek için (net metin = daha az GPU/CPU yükü, daha akıcı kaydırma)
try DllCall("SetProcessDpiAwarenessContext", "ptr", -4)

main := Gui("+Resize +MinSize400x300", "WhatsApp")
main.BackColor := "111B21"
main.OnEvent("Size", GuiResize)
main.OnEvent("Close", GuiCloseHandler)   ; X'e basınca simge durumuna küçülsün (tamamen gizlenmesin)
main.Show("w1150 h780")   ; pencere ANINDA görünsün, WebView2 arka planda hazırlanacak

; ---------------- Pencere / görev çubuğu ikonu ----------------
; Varsayılan AutoHotkey "H" ikonu yerine WhatsApp'a yakın bir ikon
; kullan (Windows'un kendi ikon setinden - shell32.dll içindeki
; sohbet balonu ikonu, tepsi ikonuyla aynı). Kendi .ico dosyanı bu
; klasöre "WhatsApp.ico" adıyla koyarsan otomatik onu kullanır.
IkonDosyasi := A_ScriptDir "\WhatsApp.ico"
if FileExist(IkonDosyasi)
    hIcon := LoadPicture(IkonDosyasi, "Icon1 w32 h32", &imgTuru)
else
    hIcon := LoadPicture("shell32.dll", "Icon174 w32 h32", &imgTuru)
if hIcon {
    SendMessage(0x80, 0, hIcon, , "ahk_id " main.Hwnd)   ; WM_SETICON, küçük ikon (başlık çubuğu)
    SendMessage(0x80, 1, hIcon, , "ahk_id " main.Hwnd)   ; WM_SETICON, büyük ikon (görev çubuğu / Alt+Tab)
}

; ---- WebView2'yi ASENKRON kur ----
; Önceki sürüm .await2() ile bloklardı: WebView2 motoru hazır olana
; kadar pencere donmuş gibi görünürdü. Şimdi .then() kullanıyoruz;
; pencere anında açılıyor, motor arkada hazırlanıp bitince otomatik
; devreye giriyor -> algılanan açılış hızı belirgin şekilde artar.
WebView2.CreateControllerAsync(main.Hwnd,
    {
        ; Performans + arka planda canlı kalma argümanları:
        AdditionalBrowserArguments:
              "--disable-background-timer-throttling"     ; arka plandayken de timer'lar yavaşlamasın (bildirimler gecikmesin)
            . " --disable-backgrounding-occluded-windows"   ; pencere kapansa/gizlense de render durmasın
            . " --disable-renderer-backgrounding"            ; sekme/pencere arka planda yavaşlatılmasın
            . " --enable-gpu-rasterization"                  ; çizimi GPU'ya yaptır, CPU'yu boşalt, akıcı kaydırma
            . " --enable-zero-copy"                          ; GPU<->CPU kopyalama adımını azalt (daha az bellek trafiği, daha akıcı scroll)
            . " --disable-features=CalculateNativeWinOcclusion,TranslateUI"  ; gereksiz Windows occlusion hesaplaması + çeviri UI kapalı
            . " --disk-cache-size=104857600"                 ; disk önbelleğini 100MB'a sabitle (sınırsız büyümesin, disk I/O azalsın)
            . " --disable-sync"                              ; gereksiz Chromium senkronizasyon servisi kapalı (WhatsApp oturumunu etkilemez)
            . " --no-default-browser-check"                  ; gereksiz kontrol atlanır, açılış birkaç ms hızlanır
            . " --disable-component-update"                  ; arka planda bileşen güncelleme kontrolü yapmasın
            ; ---- RAM tüketimini azaltan ayarlar ----
            . " --renderer-process-limit=1"                  ; WhatsApp tek sayfa, tek renderer süreci yeter (fazladan process = fazladan RAM)
            . " --disable-background-networking"             ; Chromium'un kendi arka plan servisleri (Google telemetri vb.) kapalı; WhatsApp bağlantısını etkilemez
            . " --disable-domain-reliability"                ; gereksiz ağ tanılama servisi kapalı
            . " --disable-client-side-phishing-detection"     ; yerel phishing veritabanı belleğe yüklenmesin
            . " --disable-hang-monitor"                       ; "sayfa yanıt vermiyor" izleyicisi kapalı, minik CPU/RAM tasarrufu
            . " --disable-prompt-on-repost"                   ; gereksiz diyalog mantığı kapalı
            . " --disable-extensions"                         ; eklenti alt sistemi hiç yüklenmesin
            . " --disable-component-extensions-with-background-pages"  ; arka planda sessizce çalışan gizli bileşenler kapalı
            . " --js-flags=--max-old-space-size=384"          ; WhatsApp Web'in JS motoru en fazla ~384MB heap kullansın, sınırsız büyümesin
    },
    UserDataFolder).then(_WV2_Ready, _WV2_Fail)

_WV2_Ready(controller) {
    global wvc, wv
    wvc := controller
    wv := wvc.CoreWebView2
    wvc.Fill()   ; pencereyi tamamen doldur

    ; Bildirim izin isteklerini otomatik ONAYLA (WhatsApp mesaj/arama
    ; bildirimleri bu izin olmadan hiç çalışmaz)
    wv.add_PermissionRequested(PermissionHandler)

    ; Bildirimleri KENDİMİZ yönetiyoruz ki tıklanınca WhatsApp'ı
    ; garanti şekilde öne getirebilelim (varsayılan bildirim UI'si
    ; bunu bazen düzgün yapmıyor / fark edilmiyor)
    wv.add_NotificationReceived(NotificationHandler)

    ; WebView2'nin resmi RAM hedef seviyesi: pencere görünürken "Normal"
    ; (en akıcı deneyim), gizliyken "Low" (Chromium belleği kendi içinde
    ; aktif olarak sıkıştırır/boşaltır). Bildirimler ve bağlantı bundan
    ; etkilenmez, sadece kullanılmayan bellek geri verilir.
    try wv.MemoryUsageTargetLevel := 0   ; 0 = Normal

    wv.Navigate("https://web.whatsapp.com")
}

_WV2_Fail(err) {
    TrayTip("WebView2 başlatılamadı: " (err.HasProp("Message") ? err.Message : err), "WhatsApp - Hata")
}

; ---------------- Pencere yeniden boyutlandırma (throttle'lu) ----------------
; Sürükleyerek boyutlandırırken her pixel'de Fill() çağırmak gereksiz
; yeniden düzenlemeye (reflow) sebep olur. 30ms'lik bir "debounce" ile
; sadece sürükleme durduğunda tek seferde Fill() çağırıyoruz -> boyut
; değiştirirken arayüz çok daha akıcı kalır.
global _resizeTimer := 0
GuiResize(GuiObj, MinMax, W, H) {
    global wvc, wv, _resizeTimer
    if MinMax = -1 {
        ; Simge durumuna küçültme düğmesiyle küçültüldüyse (X değil,
        ; direkt minimize butonu) de RAM hedefini düşür
        try wv.MemoryUsageTargetLevel := 1   ; 1 = Low
        return
    }
    if !wvc
        return
    try wv.MemoryUsageTargetLevel := 0   ; pencere tekrar normal boyuta dönünce akıcı moda geç
    if _resizeTimer
        SetTimer(_resizeTimer, 0)
    _resizeTimer := () => (wvc ? wvc.Fill() : 0)
    SetTimer(_resizeTimer, -30)   ; negatif = tek seferlik, 30ms sonra çalışır
}

; ---------------- İzinleri otomatik onayla ----------------
PermissionHandler(sender, args) {
    ; 1 = COREWEBVIEW2_PERMISSION_STATE_ALLOW
    args.State := 1
    args.Handled := true
}

; ---------------- Bildirimleri kendimiz göster / yönet ----------------
global sonBildirim := 0   ; tıklanınca WhatsApp'a "tıklandı" haberini vermek için

NotificationHandler(sender, args) {
    global sonBildirim
    args.Handled := true    ; varsayılan bildirim UI'sini biz devre dışı bırakıyoruz

    n := args.Notification
    sonBildirim := n        ; en son bildirimi sakla (tıklayınca kullanacağız)
    n.ReportShown()

    ; Windows'un kendi bildirim balonunu (tepsi/tray) göster
    baslik := n.Title != "" ? n.Title : "WhatsApp"
    govde := n.Body != "" ? n.Body : ""
    TrayTip(govde, baslik)
}

; Tepsi bildirimine (balona) TIKLANINCA çalışır
OnMessage(0x404, TrayBalloonClick)
TrayBalloonClick(wParam, lParam, *) {
    global sonBildirim
    ; 0x405 = NIN_BALLOONUSERCLICK -> kullanıcı balona tıkladı
    if (lParam = 0x405) {
        if sonBildirim
            sonBildirim.ReportClicked()   ; WhatsApp'a "bu bildirime tıklandı" bilgisini ver -> ilgili sohbeti açar
        ShowWhatsApp()
    }
}

; ---------------- Win+W: göster / öne getir ----------------
#w:: ShowWhatsApp()

GuiCloseHandler(*) {
    main.Minimize()
    ; Pencere gizlenince WebView2'ye "belleği düşük tut" hedefi ver ->
    ; kullanılmayan bellek sisteme geri verilir, Görev Yöneticisi'ndeki
    ; RAM kullanımı belirgin şekilde düşer. Websocket/bildirimler etkilenmez.
    try wv.MemoryUsageTargetLevel := 1   ; 1 = Low
    return true   ; varsayılan "gizle" davranışını iptal et, çünkü zaten küçülttük
}

ShowWhatsApp() {
    try {
        main.Restore()
        main.Show()
        ; Pencere tekrar görünür olunca en akıcı moda geri dön
        try wv.MemoryUsageTargetLevel := 0   ; 0 = Normal
        DllCall("user32\AllowSetForegroundWindow", "uint", -1)   ; -1 = ASFW_ANY, öne gelmeyi garantiler
        WinActivate("ahk_id " main.Hwnd)
        WinMoveTop("ahk_id " main.Hwnd)
    } catch as e {
        TrayTip("Pencere yeniden açılamadı, script'i yeniden başlat.", "WhatsApp - Hata")
    }
}

; ---------------- Tepsi (sistem tepsisi) menüsü ----------------
A_TrayMenu.Delete()
A_TrayMenu.Add("WhatsApp'ı Göster (Win+W)", (*) => ShowWhatsApp())
A_TrayMenu.Add("Geliştirici Konsolu (sorun giderme)", (*) => (wv ? wv.OpenDevToolsWindow() : TrayTip("WebView2 henüz hazır değil, biraz bekleyin.", "WhatsApp")))
A_TrayMenu.Add()
A_TrayMenu.Add("Çıkış", (*) => ExitApp())
A_TrayMenu.Default := "WhatsApp'ı Göster (Win+W)"
; Tepsi ikonu da varsa kendi ikon dosyanı kullanır, yoksa Windows'un
; sohbet balonu ikonuna düşer (üstteki başlık ikonuyla tutarlı olsun diye)
if FileExist(A_ScriptDir "\WhatsApp.ico")
    TraySetIcon(A_ScriptDir "\WhatsApp.ico")
else
    TraySetIcon("shell32.dll", 174)
